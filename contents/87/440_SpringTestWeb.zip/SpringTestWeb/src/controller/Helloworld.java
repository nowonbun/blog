package controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import dao.UserDao;
import model.User;

@Controller
public class Helloworld {
	
	@Autowired
	private UserDao userDao;
	
	@RequestMapping(value = "index.html", params = { "param" }, method = RequestMethod.GET)
	public String index1(@ModelAttribute Node node, ModelMap modelmap, HttpSession session, HttpServletRequest req,
			HttpServletResponse res) {
		modelmap.addAttribute("Data", "parameter - " + node.getParam());
		return "index";
	}

	@RequestMapping(value = "index.html", method = RequestMethod.GET)
	public String index2(ModelMap modelmap, HttpSession session, HttpServletRequest req, HttpServletResponse res) {
		StringBuffer sb = new StringBuffer();
		List<User> users = userDao.selectAll();
		for (User user : users) {
			sb.append(user.getName() + " ");
		}
		modelmap.addAttribute("Data", sb.toString());
		return "index";
	}
}

class Node {
	private String param;

	public String getParam() {
		return param;
	}

	public void setParam(String param) {
		this.param = param;
	}

}