package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the info database table.
 * 
 */
@Entity
@NamedQuery(name="Info.findAll", query="SELECT i FROM Info i")
public class Info implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idx;

	private int age;

	//bi-directional many-to-one association to User
	@ManyToOne
	@JoinColumn(name="id")
	private User user;

	//bi-directional many-to-one association to Info2
	@OneToMany(mappedBy="info", cascade = CascadeType.PERSIST)
	private List<Info2> info2s;

	public Info() {
	}

	public int getIdx() {
		return this.idx;
	}

	public void setIdx(int idx) {
		this.idx = idx;
	}

	public int getAge() {
		return this.age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<Info2> getInfo2s() {
		return this.info2s;
	}

	public void setInfo2s(List<Info2> info2s) {
		this.info2s = info2s;
	}

	public Info2 addInfo2(Info2 info2) {
		getInfo2s().add(info2);
		info2.setInfo(this);

		return info2;
	}

	public Info2 removeInfo2(Info2 info2) {
		getInfo2s().remove(info2);
		info2.setInfo(null);

		return info2;
	}

}