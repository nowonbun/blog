package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the user database table.
 * 
 */
@Entity
@NamedQuery(name="User.findAll", query="SELECT u FROM User u")
public class User implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	private String name;

	//bi-directional many-to-one association to Info
	@OneToMany(mappedBy="user", fetch = FetchType.LAZY)
	private List<Info> infos;

	//bi-directional many-to-many association to Permission
	@ManyToMany(mappedBy="users")
	private List<Permission> permissions;

	public User() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Info> getInfos() {
		return this.infos;
	}

	public void setInfos(List<Info> infos) {
		this.infos = infos;
	}

	public Info addInfo(Info info) {
		getInfos().add(info);
		info.setUser(this);

		return info;
	}

	public Info removeInfo(Info info) {
		getInfos().remove(info);
		info.setUser(null);

		return info;
	}

	public List<Permission> getPermissions() {
		return this.permissions;
	}

	public void setPermissions(List<Permission> permissions) {
		this.permissions = permissions;
	}

}