import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import model.Info;
import model.User;

public class Main {
	public static void main(String... args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JpaExample");
		EntityManager em = emf.createEntityManager();
		User user = em.find(User.class, "nowonbun");
		System.out.println(user.getName());
		List<Info> infos = user.getInfos();
		for (Info info : infos) {
			System.out.println(info.getAge());
		}
	}
}
