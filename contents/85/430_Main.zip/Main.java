import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Main {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("***persistence名***");
	EntityManager em = emf.createEntityManager();

	interface EntityManagerCallable<V> {
		V run(EntityManager em);
	}

	interface EntityManagerRunable {
		void run(EntityManager em);
	}

	// リターン値があるトランザクション
	public <V> V transaction(EntityManagerCallable<V> callable) {
		return transaction(callable, false);
	}

	public <V> V transaction(EntityManagerCallable<V> callable, boolean readonly) {
		EntityManager em = emf.createEntityManager();
		EntityTransaction transaction = em.getTransaction();
		// トランザクションを開始
		transaction.begin();
		try {
			// ラムダ式を実行する.
			V ret = callable.run(em);
			// readonlyがtrueならrollbackする。
			if (readonly) {
				transaction.rollback();
			} else {
				//トランザクションをデータベースに入力する。
				transaction.commit();
			}
			return ret;
		} catch (Throwable e) {
			// エラーが発生するとロールバックする。
			if (transaction.isActive()) {
				transaction.rollback();
			}
			throw new RuntimeException(e);
		} finally {
			em.clear();
			em.close();
		}
	}
	
	// リターン値がないトランザクション
	public void transaction(EntityManagerRunable runnable) {
		transaction(runnable, false);
	}

	public void transaction(EntityManagerRunable runnable, boolean readonly) {
		EntityManager em = emf.createEntityManager();
		EntityTransaction transaction = em.getTransaction();
		// トランザクションを開始
		transaction.begin();
		try {
			// ラムダ式を実行する。
			runnable.run(em);
			// readonlyがtrueならrollbackする。
			if (readonly) {
				transaction.rollback();
			} else {
				// トランザクションをデータベースに入力する。
				transaction.commit();
			}
		} catch (Throwable e) {
			// エラーが発生するとロールバックする。
			if (transaction.isActive()) {
				transaction.rollback();
			}
			throw new RuntimeException(e);
		} finally {
			em.clear();
			em.close();
		}
	}
}
