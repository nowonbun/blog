package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the permission database table.
 * 
 */
@Entity
@NamedQuery(name="Permission.findAll", query="SELECT p FROM Permission p")
public class Permission implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String code;

	private String name;

	//bi-directional many-to-many association to User
	@ManyToMany
	@JoinTable(
		name="permission_map"
		, joinColumns={
			@JoinColumn(name="code")
			}
		, inverseJoinColumns={
			@JoinColumn(name="id")
			}
		)
	private List<User> users;

	public Permission() {
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<User> getUsers() {
		return this.users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}

}