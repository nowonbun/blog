package func;

import java.util.List;

import dao.FactoryDao;
import dao.UserDao;
import model.User;

public class TestFunction {
	public List<User> getUsers() {
		UserDao userDao = FactoryDao.getDao(UserDao.class);
		return userDao.selectAll();
	}
}
