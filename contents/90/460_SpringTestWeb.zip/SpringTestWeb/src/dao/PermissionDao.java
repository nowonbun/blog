package dao;

import model.Permission;

public class PermissionDao extends AbstractDao<Permission> {
	protected PermissionDao() {
		super(Permission.class);
	}
}
