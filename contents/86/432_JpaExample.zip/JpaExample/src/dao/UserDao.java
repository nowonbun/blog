package dao;

import java.util.List;
import javax.persistence.Query;
import model.User;

public class UserDao extends AbstractDao<User> {
	public UserDao() {
		super(User.class);
	}

	@SuppressWarnings("unchecked")
	public List<User> selectAll() {
		return super.transaction((em) -> {
			Query query = em.createQuery("SELECT u FROM User u");
			return (List<User>) query.getResultList();
		});
	}
}
