package dao;

import model.Info;

public class InfoDao extends AbstractDao<Info> {
	public InfoDao() {
		super(Info.class);
	}
}
