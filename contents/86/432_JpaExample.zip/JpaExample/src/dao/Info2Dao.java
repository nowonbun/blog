package dao;

import model.Info2;

public class Info2Dao extends AbstractDao<Info2> {
	public Info2Dao() {
		super(Info2.class);
	}
}
