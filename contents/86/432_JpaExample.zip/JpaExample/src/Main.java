import dao.UserDao;
import model.User;

public class Main {
	public static void main(String... args) {
		UserDao dao = new UserDao();
		for (User user : dao.selectAll()) {
			System.out.println(user.getName());
		}
	}
}
