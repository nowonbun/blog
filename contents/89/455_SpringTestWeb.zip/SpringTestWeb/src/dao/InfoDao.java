package dao;

import model.Info;

public class InfoDao extends AbstractDao<Info> {
	protected InfoDao() {
		super(Info.class);
	}
}
