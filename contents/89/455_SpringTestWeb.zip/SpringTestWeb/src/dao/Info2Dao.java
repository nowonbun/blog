package dao;

import model.Info2;

public class Info2Dao extends AbstractDao<Info2> {
	protected Info2Dao() {
		super(Info2.class);
	}
}
